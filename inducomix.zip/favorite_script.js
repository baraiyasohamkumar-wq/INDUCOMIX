document.addEventListener('DOMContentLoaded', () => {
    const favoriteButtons = document.querySelectorAll('.favorite-btn');
    let favorites = JSON.parse(localStorage.getItem('favorites') || '[]');

    favoriteButtons.forEach(btn => {
        const title = btn.getAttribute('data-title');
        if (favorites.includes(title)) {
            btn.classList.add('active');
            btn.textContent = '❤️';
        }

        btn.addEventListener('click', () => {
            const title = btn.getAttribute('data-title');

            if (btn.classList.contains('active')) {
                btn.classList.remove('active');
                btn.textContent = '♡';
                favorites = favorites.filter(fav => fav !== title);
            } else {
                btn.classList.add('active');
                btn.textContent = '❤️';
                favorites.push(title);
            }

            localStorage.setItem('favorites', JSON.stringify(favorites));
        });
    });
});